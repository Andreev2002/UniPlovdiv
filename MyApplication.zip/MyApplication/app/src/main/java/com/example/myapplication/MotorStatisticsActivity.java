package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class MotorStatisticsActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motor_statistics);

        dbHelper = new DatabaseHelper(getApplicationContext());

        List<String> motorBrands = dbHelper.getAllMotorBrands();

        displayStatisticsForMotorBrands(motorBrands);
    }

    private void displayStatisticsForMotorBrands(List<String> motorBrands) {
        for (String brand : motorBrands) {
            int totalMotors = dbHelper.getTotalMotorsForBrand(brand);
            int modelCount = dbHelper.getModelCountForBrand(brand);
            int totalMileage = dbHelper.getTotalMileageForBrand(brand);
            int minHorsepower = dbHelper.getMinHorsepowerForBrand(brand);
            int maxHorsepower = dbHelper.getMaxHorsepowerForBrand(brand);
            int minYear = dbHelper.getMinYearForBrand(brand);
            int maxYear = dbHelper.getMaxYearForBrand(brand);

            // Display statistics for the current brand
            displayStatistics(brand, totalMotors, modelCount, totalMileage,
                    minHorsepower, maxHorsepower, minYear, maxYear);
        }
    }

    private void displayStatistics(String brand, int totalMotors, int modelCount,
                                   int totalMileage, int minHorsepower, int maxHorsepower,
                                   int minYear, int maxYear) {
        TextView textView = new TextView(this);
        textView.setText(String.format("Brand: %s\n\t\tTotal Motors: %d\n\t\tModel Count: %d\n\t\tTotal Mileage: %d\n\t\t" +
                        "Min Horsepower: %d\n\t\tMax Horsepower: %d\n\t\tMin Year: %d\n\t\tMax Year: %d\n\n",
                brand, totalMotors, modelCount, totalMileage, minHorsepower, maxHorsepower, minYear, maxYear));

        textView.setTextColor(Color.parseColor("#ffffff"));
        textView.setTextSize(16); // Set text size in sp
        textView.setPadding(16, 8, 16, 8); // Set padding in dp.

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        textView.setLayoutParams(params);

        // Add the TextView to your layout (replace with the appropriate layout)
        // For demonstration, assuming you have a LinearLayout in your XML with the ID "layoutContainer"
        setContentView(R.layout.activity_motor_statistics);
        LinearLayout layoutContainer = findViewById(R.id.layoutContainer); // Replace with your layout ID
        layoutContainer.addView(textView);
    }
}
