package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.regex.Pattern;

public class AddMotorActivity extends AppCompatActivity {
    
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_motor);

        this.dbHelper = new DatabaseHelper(this);

        final EditText etBrand = findViewById(R.id.etBrand);
        final EditText etModel = findViewById(R.id.etModel);
        final EditText etYear = findViewById(R.id.etYear);
        final EditText etMileage = findViewById(R.id.etMileage);
        final EditText etHorsepower = findViewById(R.id.etHorsepower);
        final EditText etColor = findViewById(R.id.etColor);
        final EditText etImageUrl = findViewById(R.id.etImageUrl);
        Button btnSaveMotor = findViewById(R.id.btnSaveMotor);

        btnSaveMotor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateField(etBrand, etModel, etYear, etMileage, etHorsepower, etColor, etImageUrl)) {
                    String brand = etBrand.getText().toString();
                    String model = etModel.getText().toString();
                    int year = Integer.parseInt(etYear.getText().toString());
                    int mileage = Integer.parseInt(etMileage.getText().toString());
                    int horsepower = Integer.parseInt(etHorsepower.getText().toString());
                    String color = etColor.getText().toString();
                    String imageUrl = etImageUrl.getText().toString();

                    Motor motor = new Motor(brand, model, year, mileage, horsepower, color, imageUrl);
                    dbHelper.addMotor(motor);

                    finish(); // Close the activity after saving the motor
                }
            }
        });

        FloatingActionButton fabAddMotor = findViewById(R.id.fabMotors);
        fabAddMotor.setOnClickListener(v -> {
            // Open AddMotorActivity
            Intent intent = new Intent(AddMotorActivity.this, MainActivity.class);
            startActivity(intent);
        });
    }

    private boolean validateField(EditText brand, EditText model, EditText year, EditText mileage, EditText horsePower, EditText color, EditText imageUrl) {
        if (isEmpty(brand) || isEmpty(model) || isEmpty(year) || isEmpty(mileage) || isEmpty(horsePower) || isEmpty(color)) {
            // Display an error message for empty fields
            showError("All fields must be filled.");
            return false;
        }

        // Validate with regex patterns
        if (!isValidBrand(brand)) {
            showError("Invalid brand.");
            return false;
        }

        if (!isValidModel(model)) {
            showError("Invalid model.");
            return false;
        }

        if (!isValidYear(year)) {
            showError("Invalid year.");
            return false;
        }

        if (!isValidMileage(mileage)) {
            showError("Invalid mileage.");
            return false;
        }

        if (!isValidHorsepower(horsePower)) {
            showError("Invalid horsepower.");
            return false;
        }

        if (!isValidColor(color)) {
            showError("Invalid color.");
            return false;
        }

        if (!isValidImageUrl(imageUrl)) {
            showError("Invalid image URL.");
            return false;
        }

        return true;
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private boolean isEmpty(EditText editText) {
        return editText.getText().toString().trim().length() == 0;
    }

    private boolean isValidBrand(EditText brandEditText) {
        // Regex pattern for a valid brand (letters and spaces only)
        String brandRegex = "^[A-Za-z\\s]+$";
        return Pattern.matches(brandRegex, brandEditText.getText().toString());
    }

    private boolean isValidModel(EditText modelEditText) {
        // Regex pattern for a valid model (letters, numbers, and spaces only)
        String modelRegex = "^[A-Za-z0-9\\s]+$";
        return Pattern.matches(modelRegex, modelEditText.getText().toString());
    }

    private boolean isValidYear(EditText yearEditText) {
        try {
            int year = Integer.parseInt(yearEditText.getText().toString());
            return year >= 0 && year <= 2023; // Assuming motors were invented in 1886 and not from the future
        } catch (NumberFormatException e) {
            return false; // If parsing fails
        }
    }

    private boolean isValidMileage(EditText mileageEditText) {
        // Regex pattern for a valid mileage (non-negative integer)
        String mileageRegex = "^[0-9]+$";
        return Pattern.matches(mileageRegex, mileageEditText.getText().toString());
    }

    private boolean isValidHorsepower(EditText horsepowerEditText) {
        // Regex pattern for a valid horsepower (non-negative integer)
        String horsepowerRegex = "^[0-9]+$";
        return Pattern.matches(horsepowerRegex, horsepowerEditText.getText().toString());
    }

    private boolean isValidColor(EditText colorEditText) {
        // Regex pattern for a valid color (letters and spaces only)
        String colorRegex = "^[A-Za-z\\s]+$";
        return Pattern.matches(colorRegex, colorEditText.getText().toString());
    }

    private boolean isValidImageUrl(EditText imageUrlEditText) {
        // Regex pattern for a valid URL
        String urlRegex = "^(https?|ftp)://[a-zA-Z0-9-]+(\\.[a-zA-Z]{2,})+(\\/[^\\s]*)?$";
        return Pattern.matches(urlRegex, imageUrlEditText.getText().toString());
    }
}
