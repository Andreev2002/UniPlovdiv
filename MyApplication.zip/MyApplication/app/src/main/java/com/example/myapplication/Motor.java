package com.example.myapplication;

public class Motor {
    private long id;
    private String brand;
    private String model;
    private int year;
    private int mileage;
    private int horsePower;
    private String color;
    private String imageUrl;

    public Motor() {
    }

    public Motor(String brand, String model, int year, int millage, int horsePower, String color, String imageUrl) {
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.mileage = millage;
        this.horsePower = horsePower;
        this.color = color;
        this.imageUrl = imageUrl;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMileage() {
        return mileage;
    }

    public void setMileage(int mileage) {
        this.mileage = mileage;
    }

    public int getHorsePower() {
        return horsePower;
    }

    public void setHorsePower(int horsePower) {
        this.horsePower = horsePower;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
