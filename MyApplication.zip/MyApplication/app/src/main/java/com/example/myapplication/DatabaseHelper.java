package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "db.motors";
    private static final int VERSION = 1;

    private SQLiteDatabase myDb;

    private final String DATABASE_CREATE =
            "CREATE TABLE motors (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "model TEXT NOT NULL," +
                    "year TEXT NOT NULL," +
                    "brand TEXT NOT NULL," +
                    "millage INTEGER NOT NULL," +
                    "horsePower INTGER NOT NULL," +
                    "color TEXT NOT NULL," +
                    "imageUrl TEXT NOT NULL" +
                    ");";

    public DatabaseHelper(@Nullable Context context) {
        super(context, DB_NAME, null, VERSION);
        this.myDb = getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(DATABASE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 1) {
            db.execSQL("DROP TABLE IF EXISTS motors;");
            db.execSQL(DATABASE_CREATE);
        }
    }

    public long addMotor(Motor motor) {
        ContentValues values = new ContentValues();
        values.put("brand", motor.getBrand());
        values.put("model", motor.getModel());
        values.put("year", motor.getYear());
        values.put("millage", motor.getMileage());
        values.put("horsePower", motor.getHorsePower());
        values.put("color", motor.getColor());
        values.put("imageUrl", motor.getImageUrl());

        long id = myDb.insert("motors", null, values);
        myDb.close();
        return id;
    }

    @SuppressLint("Range")
    public List<Motor> getAllMotors() {
        List<Motor> motorList = new ArrayList<>();
        String[] projection = {
                "id",
                "brand",
                "model",
                "year",
                "millage",
                "horsePower",
                "color",
                "imageUrl"
        };
        Cursor cursor = myDb.query(
                "motors",
                projection,
                null,
                null,
                null,
                null,
                null
        );

        while (cursor.moveToNext()) {
            Motor motor = new Motor();
            motor.setId(cursor.getLong(cursor.getColumnIndex("id")));
            motor.setBrand(cursor.getString(cursor.getColumnIndex("brand")));
            motor.setModel(cursor.getString(cursor.getColumnIndex("model")));
            motor.setYear(cursor.getInt(cursor.getColumnIndex("year")));
            motor.setMileage(cursor.getInt(cursor.getColumnIndex("millage")));
            motor.setHorsePower(cursor.getInt(cursor.getColumnIndex("horsePower")));
            motor.setColor(cursor.getString(cursor.getColumnIndex("color")));
            motor.setImageUrl(cursor.getString(cursor.getColumnIndex("imageUrl")));
            motorList.add(motor);
        }

        cursor.close();
        myDb.close();

        return motorList;
    }

    @SuppressLint("Range")
    public Motor getMotor(long motorId) {
        myDb = this.getReadableDatabase();
        String query = "SELECT * FROM " + "motors" + " WHERE " + "id" + " = ?";
        Cursor cursor = myDb.rawQuery(query, new String[]{String.valueOf(motorId)});

        Motor motor = null;
        if (cursor.moveToFirst()) {
            motor = new Motor();
            motor.setId(cursor.getLong(cursor.getColumnIndex("id")));
            motor.setBrand(cursor.getString(cursor.getColumnIndex("brand")));
            motor.setModel(cursor.getString(cursor.getColumnIndex("model")));
            motor.setYear(cursor.getInt(cursor.getColumnIndex("year")));
            motor.setMileage(cursor.getInt(cursor.getColumnIndex("millage")));
            motor.setHorsePower(cursor.getInt(cursor.getColumnIndex("horsePower")));
            motor.setColor(cursor.getString(cursor.getColumnIndex("color")));
            motor.setImageUrl(cursor.getString(cursor.getColumnIndex("imageUrl")));
        }

        cursor.close();
        myDb.close();
        return motor;
    }

    public int updateMotor(Motor motor) {
        myDb = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("brand", motor.getBrand());
        values.put("model", motor.getModel());
        values.put("year", motor.getYear());
        values.put("millage", motor.getMileage());
        values.put("horsePower", motor.getHorsePower());
        values.put("color", motor.getColor());
        values.put("imageUrl", motor.getImageUrl());

        return myDb.update("motors", values, "id" + " = ?",
                new String[]{String.valueOf(motor.getId())});
    }

    public int deleteMotor(long motorId) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("motors", "id" + " = ?",
                new String[]{String.valueOf(motorId)});
    }

    @SuppressLint("Range")
    public List<String> getAllMotorBrands() {
        List<String> motorBrands = new ArrayList<>();
        myDb = this.getReadableDatabase();

        String query = "SELECT DISTINCT " + "brand" + " FROM " + "motors";
        Cursor cursor = myDb.rawQuery(query, null);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    motorBrands.add(cursor.getString(cursor.getColumnIndex("brand")));
                } while (cursor.moveToNext());
            }
            cursor.close();
        }

        myDb.close();
        return motorBrands;
    }

    public int getTotalMotorsForBrand(String brand) {
        myDb = this.getReadableDatabase();

        String query = "SELECT COUNT(*) FROM " + "motors" +
                " WHERE " + "brand" + " = ?";
        String[] selectionArgs = {brand};
        Cursor cursor = myDb.rawQuery(query, selectionArgs);

        int totalMotors = 0;
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                totalMotors = cursor.getInt(0);
            }
            cursor.close();
        }

        myDb.close();
        return totalMotors;
    }

    @SuppressLint("Range")
    public int getModelCountForBrand(String brand) {
        myDb = this.getReadableDatabase();

        String query = "SELECT DISTINCT " + "model" + " FROM " + "motors" +
                " WHERE " + "brand" + " = ?";
        String[] selectionArgs = {brand};
        Cursor cursor = myDb.rawQuery(query, selectionArgs);

        Set<String> uniqueModels = new HashSet<>();
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    uniqueModels.add(cursor.getString(cursor.getColumnIndex("model")));
                } while (cursor.moveToNext());
            }
            cursor.close();
        }

        myDb.close();
        return uniqueModels.size();
    }

    public int getTotalMileageForBrand(String brand) {
        myDb = this.getReadableDatabase();

        String query = "SELECT SUM(" + "millage" + ") FROM " + "motors" +
                " WHERE " + "brand" + " = ?";
        String[] selectionArgs = {brand};
        Cursor cursor = myDb.rawQuery(query, selectionArgs);

        int totalMileage = 0;
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                totalMileage = cursor.getInt(0);
            }
            cursor.close();
        }

        myDb.close();
        return totalMileage;
    }

    public int getMinHorsepowerForBrand(String brand) {
        myDb = this.getReadableDatabase();

        String query = "SELECT MIN(" + "horsePower" + ") FROM " + "motors" +
                " WHERE " + "brand" + " = ?";
        String[] selectionArgs = {brand};
        Cursor cursor = myDb.rawQuery(query, selectionArgs);

        int minHorsepower = 0; // Default value or handle as needed
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                minHorsepower = cursor.getInt(0);
            }
            cursor.close();
        }

        myDb.close();
        return minHorsepower;
    }

    public int getMaxHorsepowerForBrand(String brand) {
        myDb = this.getReadableDatabase();

        String query = "SELECT MAX(" + "horsePower" + ") FROM " + "motors" +
                " WHERE " + "brand" + " = ?";
        String[] selectionArgs = {brand};
        Cursor cursor = myDb.rawQuery(query, selectionArgs);

        int maxHorsepower = 0; // Default value or handle as needed
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                maxHorsepower = cursor.getInt(0);
            }
            cursor.close();
        }

        myDb.close();
        return maxHorsepower;
    }

    public int getMinYearForBrand(String brand) {
        myDb = this.getReadableDatabase();

        String query = "SELECT MIN(" + "year" + ") FROM " + "motors" +
                " WHERE " + "brand" + " = ?";
        String[] selectionArgs = {brand};
        Cursor cursor = myDb.rawQuery(query, selectionArgs);

        int minYear = 0; // Default value or handle as needed
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                minYear = cursor.getInt(0);
            }
            cursor.close();
        }

        myDb.close();
        return minYear;
    }

    public int getMaxYearForBrand(String brand) {
        myDb = this.getReadableDatabase();

        String query = "SELECT MAX(" + "year" + ") FROM " + "motors" +
                " WHERE " + "brand" + " = ?";
        String[] selectionArgs = {brand};
        Cursor cursor = myDb.rawQuery(query, selectionArgs);

        int maxYear = 0; // Default value or handle as needed
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                maxYear = cursor.getInt(0);
            }
            cursor.close();
        }

        myDb.close();
        return maxYear;
    }
}
