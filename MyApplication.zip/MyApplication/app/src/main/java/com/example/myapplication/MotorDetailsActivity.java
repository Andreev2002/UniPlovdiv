package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.squareup.picasso.Picasso;

public class MotorDetailsActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motor_detail);

        dbHelper = new DatabaseHelper(this);

        // Get motor ID from the intent
        long motorId = getIntent().getLongExtra("motorId", -1);

        // Retrieve the selected motor from the database
        Motor selectedMotor = dbHelper.getMotor(motorId);

        // Display motor details
        TextView brandModelTextView = findViewById(R.id.brandModelDetailTextView);
        TextView yearTextView = findViewById(R.id.yearDetailTextView);
        TextView mileageTextView = findViewById(R.id.mileageDetailTextView);
        TextView horsepowerTextView = findViewById(R.id.horsepowerDetailTextView);
        TextView colorTextView = findViewById(R.id.colorDetailTextView);
        ImageView imageView = findViewById(R.id.image);

        brandModelTextView.setText(String.format("%s %s", selectedMotor.getBrand(), selectedMotor.getModel()));
        yearTextView.setText(String.format("Year: %d", selectedMotor.getYear()));
        mileageTextView.setText(String.format("Mileage: %d km.", selectedMotor.getMileage()));
        horsepowerTextView.setText(String.format("Horsepower: %d", selectedMotor.getHorsePower()));
        colorTextView.setText(String.format("Color: %s", selectedMotor.getColor()));
        loadImageFromUrl(selectedMotor.getImageUrl(), imageView);

        // Set click listeners for Edit and Delete buttons
        Button btnEditMotor = findViewById(R.id.btnEditMotor);
        Button btnDeleteMotor = findViewById(R.id.btnDeleteMotor);

        btnEditMotor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle Edit button click
                openEditMotorActivity(selectedMotor.getId());
            }
        });

        btnDeleteMotor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle Delete button click
                dbHelper.deleteMotor(motorId);
                finish(); // Close the current activity after deleting the motor
            }
        });

        FloatingActionButton fabAddMotor = findViewById(R.id.fabMotors);
        fabAddMotor.setOnClickListener(v -> {
            // Open AddMotorActivity
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        });
    }

    private void openEditMotorActivity(long id) {
        Intent intent = new Intent(this, EditMotorActivity.class);
        intent.putExtra("motor_id", id);
        startActivity(intent);
    }

    private void loadImageFromUrl(String imageUrl, final ImageView imageView) {
        Picasso.get()
                .load(imageUrl)
                .into(imageView);
    }
}
