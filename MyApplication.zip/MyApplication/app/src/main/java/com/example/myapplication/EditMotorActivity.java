package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.regex.Pattern;

public class EditMotorActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private Motor motor;

    private EditText brandEditText;
    private EditText modelEditText;
    private EditText yearEditText;
    private EditText mileageEditText;
    private EditText horsepowerEditText;
    private EditText colorEditText;
    private EditText imageUrlEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_motor);

        dbHelper = new DatabaseHelper(this);

        // Initialize UI components
        brandEditText = findViewById(R.id.editBrandEditText);
        modelEditText = findViewById(R.id.editModelEditText);
        yearEditText = findViewById(R.id.editYearEditText);
        mileageEditText = findViewById(R.id.editMileageEditText);
        horsepowerEditText = findViewById(R.id.editHorsepowerEditText);
        colorEditText = findViewById(R.id.editColorEditText);
        imageUrlEditText = findViewById(R.id.editImageUrlEditText);

        Button btnSaveChanges = findViewById(R.id.btnSaveChanges);
        btnSaveChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateMotor(brandEditText, modelEditText, yearEditText, mileageEditText, horsepowerEditText, colorEditText, imageUrlEditText);
            }
        });

        // Retrieve the motor details passed from the previous activity
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.containsKey("motor_id")) {
            long motorId = extras.getLong("motor_id");
            motor = dbHelper.getMotor(motorId);

            if (motor != null) {
                // Set the current motor details to the UI
                brandEditText.setText(motor.getBrand());
                modelEditText.setText(motor.getModel());
                yearEditText.setText(String.valueOf(motor.getYear()));
                mileageEditText.setText(String.valueOf(motor.getMileage()));
                horsepowerEditText.setText(String.valueOf(motor.getHorsePower()));
                colorEditText.setText(motor.getColor());
                imageUrlEditText.setText(motor.getImageUrl());
            }
        } else {
            // Handle the case where no motor ID is provided
            finish(); // Close the activity if there's no valid motor ID
        }
    }

    private void updateMotor(EditText brandEditText, EditText modelEditText, EditText yearEditText, EditText mileageEditText, EditText horsepowerEditText, EditText colorEditText, EditText imageUrlEditText) {
        // Validate input before updating
        if (isValidInput(brandEditText, modelEditText, yearEditText, mileageEditText, horsepowerEditText, colorEditText, imageUrlEditText)) {
            // Update the motor details if input is valid
            motor.setBrand(brandEditText.getText().toString());
            motor.setModel(modelEditText.getText().toString());
            motor.setYear(Integer.parseInt(yearEditText.getText().toString()));
            motor.setMileage(Integer.parseInt(mileageEditText.getText().toString()));
            motor.setHorsePower(Integer.parseInt(horsepowerEditText.getText().toString()));
            motor.setColor(colorEditText.getText().toString());
            motor.setImageUrl(imageUrlEditText.getText().toString());

            dbHelper.updateMotor(motor);
            finish(); // Close the EditMotorActivity after updating
        }
    }

    private boolean isValidInput(EditText brand, EditText model, EditText year, EditText mileage, EditText horsePower, EditText color, EditText imageUrl) {
        if (isEmpty(brand) || isEmpty(model) || isEmpty(year) || isEmpty(mileage) || isEmpty(horsePower) || isEmpty(color) || isEmpty(imageUrl)) {
            // Display an error message for empty fields
            showError("All fields must be filled.");
            return false;
        }

        // Validate with regex patterns
        if (!isValidBrand(brand)) {
            showError("Invalid brand.");
            return false;
        }

        if (!isValidModel(model)) {
            showError("Invalid model.");
            return false;
        }

        if (!isValidYear(year)) {
            showError("Invalid year.");
            return false;
        }

        if (!isValidMileage(mileage)) {
            showError("Invalid mileage.");
            return false;
        }

        if (!isValidHorsepower(horsePower)) {
            showError("Invalid horsepower.");
            return false;
        }

        if (!isValidColor(color)) {
            showError("Invalid color.");
            return false;
        }

        if (!isValidImageUrl(imageUrl)) {
            showError("Invalid image URL.");
            return false;
        }

        return true;
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private boolean isEmpty(EditText editText) {
        return editText.getText().toString().trim().length() == 0;
    }

    private boolean isValidBrand(EditText brandEditText) {
        // Regex pattern for a valid brand (letters and spaces only)
        String brandRegex = "^[A-Za-z\\s]+$";
        return Pattern.matches(brandRegex, brandEditText.getText().toString());
    }

    private boolean isValidModel(EditText modelEditText) {
        // Regex pattern for a valid model (letters, numbers, and spaces only)
        String modelRegex = "^[A-Za-z0-9\\s]+$";
        return Pattern.matches(modelRegex, modelEditText.getText().toString());
    }

    private boolean isValidYear(EditText yearEditText) {
        try {
            int year = Integer.parseInt(yearEditText.getText().toString());
            return year >= 0 && year <= 2023; // Assuming motors were invented in 1886 and not from the future
        } catch (NumberFormatException e) {
            return false; // If parsing fails
        }
    }

    private boolean isValidMileage(EditText mileageEditText) {
        // Regex pattern for a valid mileage (non-negative integer)
        String mileageRegex = "^[0-9]+$";
        return Pattern.matches(mileageRegex, mileageEditText.getText().toString());
    }

    private boolean isValidHorsepower(EditText horsepowerEditText) {
        // Regex pattern for a valid horsepower (non-negative integer)
        String horsepowerRegex = "^[0-9]+$";
        return Pattern.matches(horsepowerRegex, horsepowerEditText.getText().toString());
    }

    private boolean isValidColor(EditText colorEditText) {
        // Regex pattern for a valid color (letters and spaces only)
        String colorRegex = "^[A-Za-z\\s]+$";
        return Pattern.matches(colorRegex, colorEditText.getText().toString());
    }

    private boolean isValidImageUrl(EditText imageUrlEditText) {
        // Regex pattern for a valid URL
        String urlRegex = "^(https?|ftp)://[a-zA-Z0-9-]+(\\.[a-zA-Z]{2,})+(\\/[^\\s]*)?$";
        return Pattern.matches(urlRegex, imageUrlEditText.getText().toString());
    }
}
