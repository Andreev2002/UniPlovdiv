package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private MotorListAdapter motorListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(getApplicationContext());

        // Get a list of all motors from the database
        List<Motor> motorList = dbHelper.getAllMotors();

        motorListAdapter = new MotorListAdapter(this, motorList);
        ListView motorListView = findViewById(R.id.motorListView);
        motorListView.setAdapter(motorListAdapter);

        motorListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Motor selectedMotor = (Motor) parent.getItemAtPosition(position);
                openMotorDetailActivity(selectedMotor.getId());
            }
        });

        Button btnMotorStatistics = findViewById(R.id.btnMotorStatistics);
        btnMotorStatistics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMotorStatisticsActivity();
            }
        });

        FloatingActionButton fabAddMotor = findViewById(R.id.fabAddMotor);
        fabAddMotor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open AddMotorActivity
                Intent intent = new Intent(MainActivity.this, AddMotorActivity.class);
                startActivity(intent);
            }
        });
    }

    // Method to open MotorDetailActivity with the selected motor's ID
    private void openMotorDetailActivity(long motorId) {
        Intent intent = new Intent(this, MotorDetailsActivity.class);
        intent.putExtra("motorId", motorId);
        startActivity(intent);
    }

    private void openMotorStatisticsActivity() {
        Intent intent = new Intent(this, MotorStatisticsActivity.class);
        startActivity(intent);
    }
}