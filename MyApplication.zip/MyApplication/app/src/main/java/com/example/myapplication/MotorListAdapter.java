package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class MotorListAdapter extends BaseAdapter {

    private Context context;
    private List<Motor> motorList;
    private DatabaseHelper dbHelper;

    public MotorListAdapter(Context context, List<Motor> motorList) {
        this.context = context;
        this.motorList = motorList;
    }

    @Override
    public int getCount() {
        return motorList.size();
    }

    @Override
    public Object getItem(int position) {
        return motorList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return motorList.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            view = inflater.inflate(R.layout.items_motor_list, parent, false);
        }

        final Motor motor = motorList.get(position);

        TextView brandModelTextView = view.findViewById(R.id.brandModelTextView);
        TextView yearTextView = view.findViewById(R.id.yearTextView);

        brandModelTextView.setText(String.format("%s %s", motor.getBrand(), motor.getModel()));
        yearTextView.setText(String.format("Year: %d", motor.getYear()));

        return view;
    }
}
